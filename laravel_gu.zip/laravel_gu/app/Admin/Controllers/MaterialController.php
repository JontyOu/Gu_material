<?php

namespace App\Admin\Controllers;

use App\Models\Materials;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class MaterialController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = '素材管理';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Materials());

        $grid->column('id', __('Id'));
        $grid->column('content', '内容')->display(function ($content){
            if(strlen($content)>21){
                return substr($content,0,21).'……';
            }
            return $content;
        });
        $grid->column('link', __('图片/视频'))->display(function ($link){
//            if(strlen($content)>21){
//                return substr($content,0,21).'……';
//            }
            return $link;
        });
        $grid->column('type', __('类型'));
        $grid->column('time', __('时间'));
        $grid->column('class_id', __('分类'));
        $grid->column('status', __('状态'));
//        $grid->column('is_del', __('Is del'));
//        $grid->column('created_at', __('Created at'));
//        $grid->column('updated_at', __('Updated at'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Materials::findOrFail($id));

//        $show->field('id', __('Id'));
//        $show->field('内容', __('Content'));
//        $show->field('图片/视频', __('Link'));
//        $show->field('类型', __('Type'));
//        $show->field('时间', __('Time'));
//        $show->field('分类', __('Class id'));
//        $show->field('状态', __('Status'));
//        $show->field('is_del', __('Is del'));
//        $show->field('created_at', __('Created at'));
//        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Materials());

        $form->textarea('content', __('内容'));
        $form->multipleImage('link', '图片/视频')->uniqueName();
//        $form->textarea('link', __('图片/视频'));
        $form->switch('type', __('类型'));
        $form->number('time', __('时间'));
        $form->number('class_id', __('类别'));
        $form->switch('status', __('状态'))->default(1);
//        $form->switch('is_del', __('Is del'));

        return $form;
    }
}
