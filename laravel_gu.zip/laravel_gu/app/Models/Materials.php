<?php
/**
 * Created by PhpStorm.
 * User: wentao
 * Date: 2020/3/7
 * Time: 17:04
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Materials extends Model
{
    protected $table = 'material';
    protected $guarded = ['id'];

    public static function getMaterialByClassId($class_id)
    {
        if ($class_id) {
            $data = Materials::where(['class_id' => $class_id, 'status' => 1, 'is_del' => 0])
                ->select('id','content','status','link','type','class_id')
                ->paginate(10);
        } else {
            $data = Materials::where(['status' => 1, 'is_del' => 0])
                ->select('id','content','status','link','type','class_id')
                ->paginate(10);
        }
        return $data;
    }

    public static function getMaterialById($id){

        $data = Materials::where(['id'=>$id,'status' => 1, 'is_del' => 0])
            ->select('id','content','status','link','type','class_id')
            ->first();
        return $data;
    }

    public function setLinkAttribute($image)
    {
        $this->attributes['link'] = json_encode($image);
    }

    public function getLinkAttribute($image)
    {
        $image_data=json_decode($image, true);
//        foreach ($image_data as &$value){
//            $value=$_SERVER['SERVER_NAME'].'/'.$value;
//        }
        return $image_data;
    }

}